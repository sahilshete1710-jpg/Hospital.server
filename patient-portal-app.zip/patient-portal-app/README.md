# Mediscribe — Patient Portal (Frontend Prototype)

A React + Vite + Tailwind frontend for the Patient Portal dashboard: appointments,
prescriptions, medical reports, bills & payments, treatment history timeline, and
video consultation — all with mock data and client-side interactivity (booking modal,
section navigation).

## Run locally

```bash
npm install
npm run dev
```

Then open the local URL Vite prints (usually http://localhost:5173).

## Build for production

```bash
npm run build
npm run preview
```

## Structure

```
index.html          entry HTML
src/main.jsx         React root
src/App.jsx           the full dashboard (all sections + components)
src/index.css        Tailwind directives
tailwind.config.js
postcss.config.js
vite.config.js
```

## Notes

- All data (appointments, prescriptions, reports, bills, treatment history) is
  mocked in `src/App.jsx` — swap in real API calls where indicated to connect
  to a backend.
- Uses `lucide-react` for icons — already listed in `package.json`.
- No routing library is used; sections are switched via local component state
  (`active` in `App.jsx`). Swap in `react-router` if you want real URLs per section.
